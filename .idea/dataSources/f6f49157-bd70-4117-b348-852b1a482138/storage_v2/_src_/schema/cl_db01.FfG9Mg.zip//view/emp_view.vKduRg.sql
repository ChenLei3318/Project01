CREATE VIEW emp_view AS
  SELECT
    `cl_db01`.`emp`.`empno`      AS `empno`,
    `cl_db01`.`emp`.`ename`      AS `ename`,
    `cl_db01`.`dept`.`dname`     AS `dname`,
    `cl_db01`.`salgrade`.`grade` AS `grade`
  FROM `cl_db01`.`emp`
    JOIN `cl_db01`.`dept`
    JOIN `cl_db01`.`salgrade`
  WHERE ((`cl_db01`.`emp`.`deptno` = `cl_db01`.`dept`.`deptno`) AND
         (`cl_db01`.`emp`.`sal` BETWEEN `cl_db01`.`salgrade`.`losal` AND `cl_db01`.`salgrade`.`hisal`));

